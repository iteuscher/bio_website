
<html>
	<head>
	<title> Assassin_Join_Game </title>

	</head>
	<body>
	
	
	
	<?php 

//info to conncect to mamp mysql server
$driver = "mysql";
$user = 'root';
$password = 'root';
$db = 'my_db';
$host = 'localhost';
$port = 8889;


//Connect to sql server
$link = mysqli_connect(
   "$host:$port", 
   $user, 
   $password ) or die('Unable to connect');
   
 echo "Connection successful.<br>";



//Select database
mysqli_select_db($link, $db);



//get information from client
$player = "";
if (isset($_GET['player']))
{
    $player = $_GET['player'];
    
    $player = json_decode($player, true);
    $firstname = $player['firstname'];
    $lastname = $player['lastname'];
    $email = $player['email'];
    $idG = $player['ID'];
    //var_dump($player);   
}
else
{
    echo 'error getting player information';
    die();
}


//Call join game function 
joinGame($email, $idG);




/*
    adds player to db if not exists, adds to game
    @rtn true if added, false otherwise
*/
function joinGame($email, $idG)
{
    global $link;
    global $firstname;
    global $lastname;
    
    //global sentemail and others
    
    $result = mysqli_query($link, "SELECT * FROM players WHERE email LIKE '$email'");
    
    if (mysqli_num_rows($result) == 0)
    {
        addNewPlayerToDatabase($firstname, $lastname, $email);
    }
    
    

    $result2 = mysqli_query($link, "SELECT * FROM settings WHERE idG LIKE '$idG'");
    
    if (mysqli_num_rows($result2) == 0)
    {
        $array = array("result" => "invalid gameID");
    }
    else
    {
        //check if player is already in game
        addPlayerToGame($firstname, $lastname, $email);
        $array = array("result" => "waiting");
    }
    
    echo (json_encode($array));
}



/*
    adds player to db if not exists
*/
function addNewPlayerToDatabase($firstname, $lastname, $email)
{
    global $link;
    global $idG;
    
     if ($insert = mysqli_prepare($link, "INSERT INTO players (firstname,lastname,email) VALUES (?, ?, ?)"))
     {
         mysqli_stmt_bind_param($insert, 'sss', $firstname, $lastname, $email);

        /* values already set */
     
        /* execute prepared statement */
        mysqli_stmt_execute($insert);

        printf("%d Row inserted.\n", mysqli_stmt_affected_rows($insert));
    }
    
    //check for error
    else 
    {
    	print( mysqli_error($link) );
    }

    /* close insert statement */
    mysqli_stmt_close($insert) or die ('Did not close insert statement');
}


/*
    adds player to game
    @rtn true if added, false otherwise
*/
function addPlayerToGame($firstname, $lastname, $email)
{
    global $link;
    global $idG;
    
   	    $target = null;
        $killedBy = null;
    
    if ($insert = mysqli_prepare($link, "INSERT INTO $idG (firstname, lastname, email, target, killedBy) VALUES (?, ?, ?, ?, ?)"))
    {
        mysqli_stmt_bind_param($insert, 'sssss', $firstname, $lastname, $email, $target, $killedBy); 
        
        /* execute prepared statement */
        mysqli_stmt_execute($insert);

        printf("%d Row inserted.\n", mysqli_stmt_affected_rows($insert));
    }

    //check for error
    else 
    {
    	//var_dump($idG);
    	print( mysqli_error($link));
    }

    /* close insert statement */
    mysqli_stmt_close($insert) or die ('Didnt end insert statement');
    
    $array = array("result" => "true");
    
    //returns java-readable GameID
    echo (json_encode($array));
}



//close link to server
mysqli_close($link);


//end php script
	?>
	
	
	</body>
</html>

