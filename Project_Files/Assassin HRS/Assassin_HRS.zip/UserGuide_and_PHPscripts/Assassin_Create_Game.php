<?php
//info to connect to mamp mysql server
$driver = "mysql";
$user = 'root';
$password = 'root';
$db = 'my_db';
$host = 'localhost';
$port = 8889;




//Connect to sql server
$link = mysqli_connect(
   "$host:$port", 
   $user, 
   $password ) or die('Unable to connect');
   
 echo "Connection successful.<br>";





//select database
mysqli_select_db($link, $db) or die ('Unable to select db');





//communicate with client to get information
$settings = "";
$sock = 0;
$spoon = 0;
$nerf = 0;
$email = "";

if (isset($_GET['settings']))
{
    $settings = $_GET['settings'];
    
    $settings = json_decode($settings, true);
    $sock = $settings['sock'];
    $spoon = $settings['spoon'];
    $nerf = $settings['nerf'];
    $email = $settings['email'];
    
   
}
else
{
    echo 'error getting settings ';
    die();
}





//method that will run upon opening
createNewGame($sock, $nerf, $spoon, $email);





/*
creates a new game
@rtn id of the game
*/
function createNewGame($sock, $nerf, $spoon, $email)
{
    global $link;
    
    echo $sock;
    
    if ($insert = mysqli_prepare($link, "INSERT INTO settings (idG, sock, nerf, spoon, start, requests) VALUES (?, ?, ?, ?, ?, ?)"))
    {     
        mysqli_stmt_bind_param($insert, 'siiiii', $idG, $sock, $nerf, $spoon, $start, $requests);
        
        $idG = generateRandomString(8);
        $start = 0;
        $requests = 0;




		echo $idG;
		
		
		
        /* execute prepared statement */
        mysqli_stmt_execute($insert);

       printf("%d Row inserted.\n"   );  //, mysqli_stmt_affected_rows($insert));  
        
        
        
        
        
       echo $idG;
    }

		
		
		
		
    //check for error
    else 
    {
    	print( mysqli_error($link));
    }

    /* close insert statement */
    mysqli_stmt_close($insert) or die ('Didnt end insert statement');
    
    //makes table $idG that contains all players in game in the database
  if (mysqli_query($link, "CREATE TABLE $idG(
  id INT(8) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  firstname VARCHAR (32) NOT NULL,
  lastname VARCHAR(32) NOT NULL,
  email VARCHAR(128) NOT NULL,
  target VARCHAR(128) NOT NULL,
  killedBy VARCHAR(128) NOT NULL)") !== FALSE ) 
  {
     echo "Game created! <br>";
  } 
  else 
  {
     echo 'Error creating game: ' . mysql_error() . "<br>";
  }
    
    
    
    
    echo $idG;
    
    $array = array("id" => $idG,
                    "result" => "true");
    
    //returns java-readable GameID
    echo (json_encode($array));
    
    
    
    //send email with Game ID
    $to = $email;
         $subject = "Assassin Game ID";
         

    $message = "<p> Thank you for making a new assasssin game with us! </p>";
 	$message .= "<p> To play simply press join game in the app and then input your name and the Game ID below. <p>";
  	$message .= " <p> ps: its easiest to copy and paste the Game ID to share! <p>" ;
    $message .= "<b>Here is your game ID:</b>". $idG;
         
         $header = "From:devteam@hrsassassin.io\r\n";
         $header .= "MIME-Version: 1.0\r\n";
         $header .= "Content-type: text/html\r\n";
         
         $sent = mail ($to,$subject,$message,$header);
         
         if( $sent == true ) {
            echo "Message sent successfully!";
         }
         
         else {
            echo "Message failed to sent...";
         }
    
}


/*
    @rtn string of length $length
*/
function generateRandomString($length) 
{
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = ' ';
    for ($i = 0; $i < $length; $i++) 
    {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}


/* close connection */
mysqli_close($link);

//end php script
?>
