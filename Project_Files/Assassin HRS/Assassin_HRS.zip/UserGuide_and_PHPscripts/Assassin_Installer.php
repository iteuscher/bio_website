
<html>
	<head>
	<title> Assassin_Installer </title>

	</head>
	<body>
	
	
	
	<?php 

//info to conncect to mamp mysql server
$driver = "mysql";
$user = 'root';
$password = 'root';
$db = 'my_db';
$host = 'localhost';
$port = 8889;


//Connect to sql server
$link = mysqli_connect(
   "$host:$port", 
   $user, 
   $password ) or die('Unable to connect');
   
 echo "Connection successful.<br>";

/*
creates database and adds tables gameStart, players, and settings to it

*/

//Create database   
   if (mysqli_query($link, "CREATE DATABASE IF NOT EXISTS my_db") !== FALSE ) {
    echo "Database 'my_db' created successfully <br>";
} else {
    echo 'Error creating database: ' . mysql_error() . "<br>";
}


//select the database 'my_db'
if (mysqli_select_db($link, $db)) 
{
    echo "Successfully linked to 'my_db' <br>";
} else {
    echo 'Error linking to "my_db": ' . mysql_error() . "<br>";
}



//makes table players in the database
  if (mysqli_query($link, "CREATE TABLE IF NOT EXISTS players(
id INT(8) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
firstname VARCHAR (32) NOT NULL,
lastname VARCHAR(32) NOT NULL,
email VARCHAR(128) NOT NULL)") !== FALSE ) {
    echo "Table players created! <br>";
} else {
    echo 'Error creating table players: ' . mysql_error() . "<br>";
}



//makes table settings in the database
  if (mysqli_query($link, "CREATE TABLE IF NOT EXISTS settings(
id INT(8) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
idG VARCHAR (9) NOT NULL,
sock INT(1) NOT NULL,
nerf INT(1) NOT NULL,
spoon INT(1) NOT NULL,
start INT(1) NOT NULL,
requests INT(2) NOT NULL)") !== FALSE ) {
    echo "Table settings created! <br>";
} else {
    echo 'Error creating table settings: ' . mysql_error() . "<br>";
}



//close link to server
mysqli_close($link);


//end php script
	?>
	
	
	</body>
</html>

